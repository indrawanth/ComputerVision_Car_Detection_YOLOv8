# Cruise Control Car Detection > Data sudah di Split Training
https://universe.roboflow.com/indrwan/cruise-control-car-detection

Provided by a Roboflow user
License: CC BY 4.0

